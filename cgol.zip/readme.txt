CSC 310: Conway's Game of Life
Isaac Pontarelli, Sean Polin, Alec Smith

Instructions:
1. run game.py
2. enter board size (integer)
3. enter number of generations to run or type "-1" for 
infinite generation

The main function is the top level function and is located at the bottom of 
the file

The github repo for this project can be found at /ipont/cgol
